# Задача 5
price_amount_to_pay = 0

# Задача 1 
print("Това е лексикона на Марка - искам да знам всичко")
print("===================================")

# Задача 2
first_name  = input('въведи първо име ?')

# Тази операция няма да промени стойността на price_amount_to_pay
# а просто ще извърши събиране на две числя
# price_amount_to_pay + 1.5

# Тази операция ще извърши събиране на две числа - след което 
# ще извърши операцията ПРИСВОЯВАНЕ.
# price_amount_to_pay = price_amount_to_pay + 1.5

price_amount_to_pay = price_amount_to_pay + 1.5

# price_amount_to_pay = price_amount_to_pay + 1.5
print('Ти отговори на въпрос дължиш ' + str(price_amount_to_pay))

last_name   = input('въведи второ име ?')
price_amount_to_pay = price_amount_to_pay + 1.5
print('Ти отговори на въпрос дължиш ' + str(price_amount_to_pay))

full_name   = first_name + ' ' + last_name

# Задача 3
user_weight         = input(full_name + ' колко тежиш?')
price_amount_to_pay = price_amount_to_pay + 1.5
print('Ти отговори на въпрос дължиш ' + str(price_amount_to_pay))

user_weight_metric  = input(full_name + ' в каква единица си мериш теглото ?')
price_amount_to_pay = price_amount_to_pay + 1.5
print('Ти отговори на въпрос дължиш ' + str(price_amount_to_pay))

user_height         = input(full_name + ' колко си висок?')
price_amount_to_pay = price_amount_to_pay + 1.5
print('Ти отговори на въпрос дължиш ' + str(price_amount_to_pay))

user_height_metric  = input(full_name + ' в каква единица си мериш височината?')
price_amount_to_pay = price_amount_to_pay + 1.5
print('Ти отговори на въпрос дължиш ' + str(price_amount_to_pay))

print(full_name + "ти си висок " + user_height + " " + 
      user_height_metric + " и тежиш " + user_weight + " " + user_weight_metric )

# Задача 4
parfume_volume = 150.0
parfume_signature = "C7544"
liquore_valume = 5
liquore_signature = "M7441"
bonbon_count = 25
# bonbon_size = 25
bonbon_signature = "S6491"
money_ammount = 410.54
monney_signature = "P7485"

# 
